package kr.ac.koreatech.yoonchul.a2017_1_mosyp_term;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by yoonchul on 2017-06-08.
 */

public class DBHelper extends SQLiteOpenHelper {
    private static final String DBName = "racket.db";
    private static final int DBVer = 1;
    public DBHelper(Context context){super(context,DBName, null, DBVer);}

    @Override
    public void onCreate(SQLiteDatabase db) {
        //ismoving 0 이면 정지, 1이면 움직임
        //isinside 0 이면 실외, 1이면 실내
        db.execSQL(
                "Create table contacts(_id integer primary key autoincrement,ismoving integer,place text, time text ,isinside int);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
    }
}
