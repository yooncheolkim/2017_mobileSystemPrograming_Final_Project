package kr.ac.koreatech.yoonchul.a2017_1_mosyp_term;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.PowerManager;
import android.util.Log;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by yoonchul on 2017-06-07.
 */

public class WIFIMonitor {

    private final String LOGTAG = "WIFIMonitor";
    WifiManager wifiManager;
    List<ScanResult> scanResultList;
    Context context;

    String place = null;


    public WIFIMonitor(Context context){
        this.context = context;
    }
    BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if(action.equals(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)) {
                Log.d(LOGTAG, "getWIFIinfo()");
                getWifiInfo();
            }
        }
    };

    //신호세기가 가장큰 세개의 값을 얻어, b212와 다산 로비와 비교 분석.
    private void getWifiInfo(){
        Log.d(LOGTAG, "start wifiInfo");
        scanResultList = wifiManager.getScanResults();

        List<ScanResult> scanResultList2 = new ArrayList<ScanResult>();
        // RSSI 크기가 가장 큰 것의 BSSID, SSID, RSSI 값을 얻음
        for(int i = 0; i < scanResultList.size(); i++) {
            ScanResult result = scanResultList.get(i);
            //신호세기가 큰 것만 골라내기.
            if ( result.level > -70 ) {
                scanResultList2.add(result);
            }
        }

        for(int i=0; i< scanResultList2.size() ; i++) {
            ScanResult result = scanResultList2.get(i);
            Log.d(LOGTAG, "SSID : " + result.SSID + " BSSID : " + result.BSSID + " level : " + result.level);
        }

        //얻은 값과 미리 설정해 놓은 b212, 다산 홀 와이파이 스캔 결과 비교

        for(int i=0; i<scanResultList2.size(); i++){
            ScanResult result = scanResultList2.get(i);
            if(result.BSSID.equals("90:9f:33:5a:33:2a") || result.BSSID.equals("90:9f:33:59:33:2a")){
                Log.d(LOGTAG, "i`m in B211");
                place = "B211";
                break;
            }
            if(result.BSSID.equals("20:3a:07:9e:a6:ca") || result.BSSID.equals("20:3a:07:9e:a6:ce") || result.BSSID.equals("20:3a:07:9e:a6:cf")){
                Log.d(LOGTAG, "i`m in dasan");
                place = "dasan";
                break;
            }
            place = null;
        }

        onStop();
    }

    public void onStart(){
        place = null;
        if(wifiManager == null){
            wifiManager = (WifiManager)context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);

        }
        Log.d(LOGTAG, "get wifiManger ");
        IntentFilter filter = new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
        context.registerReceiver(mReceiver, filter);
        wifiManager.startScan();
        Log.d(LOGTAG, "wifi scan start");
    }


    public void onStop(){
        Log.d(LOGTAG,"wifi onstop() ");
        context.unregisterReceiver(mReceiver);
    }

    public String getPlace(){
        Log.d(LOGTAG, "wifi scan result :" + place);
        return place;
    }
    public void setPlace(String place){
        this.place = place;
    }
}
