package kr.ac.koreatech.yoonchul.a2017_1_mosyp_term;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.CountDownTimer;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity  {

    final private String LOGTAG = "selectDB";
    private int steps;
    private TextView mTotalTime;
    private TextView mTotalStep;
    private TextView resultText;
    private TextView mStartTime;
    String result;
    private CountDownTimer timer;

    boolean isPermitted = false;
    final int MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION = 1;

   //SensorManager sm;
   //Sensor mCounter;
    int firstvalue = 0;

    private DBHelper helper;
    private SQLiteDatabase db;
    private Cursor c;

    private boolean checkStartbutton = false;
    private boolean isViewUpdateReceiver = false;

    private BroadcastReceiver MyStepReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals("StepCounter")) {
                steps = intent.getIntExtra("steps", 0);
                mTotalStep.setText("steps : " + steps);
            }
        }
    };

    private BroadcastReceiver ViewUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals("kr.ac.koreatech.msp.recordeAlarm")) {
                //뷰 1분마다 뷰 업데이트, 알람 기록 할때마다 뷰를 업데이트 해준다.
                firstvalue++;
                mTotalTime.setText("Moving Time : " + firstvalue + "분");
                timer = new CountDownTimer(2000, 2000) {
                    @Override
                    public void onTick(long l) {
                    }

                    @Override
                    public void onFinish() {
                        updateScrollView();
                        Log.d(LOGTAG, "View update");
                    }
                };
                timer.start();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTotalStep = (TextView) findViewById(R.id.tvTotalStep);
        mTotalTime = (TextView) findViewById(R.id.tvTotalTime);
        resultText = (TextView) findViewById(R.id.result);
        mStartTime = (TextView) findViewById(R.id.tvStartTime);

        //sm = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        //mCounter = sm.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR);

        helper = new DBHelper(this);
        db = helper.getReadableDatabase();


        requestRuntimePermission();
    }

    private void requestRuntimePermission() {
        //*******************************************************************
        // Runtime permission check
        //*******************************************************************
        if (ContextCompat.checkSelfPermission(MainActivity.this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {

                // Show an expanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.

            } else {

                // No explanation needed, we can request the permission.

                ActivityCompat.requestPermissions(MainActivity.this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION);
            }
        } else {
            // ACCESS_FINE_LOCATION 권한이 있는 것
            isPermitted = true;
        }
        //*********************************************************************
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // read_external_storage-related task you need to do.

                    // ACCESS_FINE_LOCATION 권한을 얻음
                    isPermitted = true;

                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.

                    // 권한을 얻지 못 하였으므로 location 요청 작업을 수행할 수 없다
                    // 적절히 대처한다
                    isPermitted = false;

                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }


    @Override
    protected void onResume() {
        super.onResume();


        IntentFilter intentFilter = new IntentFilter("StepCounter");
        //sm.registerListener(this, mCounter, SensorManager.SENSOR_DELAY_FASTEST);
        registerReceiver(MyStepReceiver, intentFilter);

        mTotalStep.setText("steps : " + steps);
        if(checkStartbutton == true) {
            updateScrollView();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopService(new Intent(this, PeriodicMonitorService.class));
        if(isViewUpdateReceiver == true) {
            unregisterReceiver(ViewUpdateReceiver);
        }
        unregisterReceiver(MyStepReceiver);
    }

    public void onClick(View v) {
        if (v.getId() == R.id.btStart) {
            if(checkStartbutton == true)
                Toast.makeText(getApplicationContext() ,"Service already Start",Toast.LENGTH_SHORT).show();
            else {
                checkStartbutton = true;
                mTotalStep.setText("steps : 0");
                Intent intent = new Intent(this, PeriodicMonitorService.class);
                startService(intent);
                IntentFilter intentFilter1 = new IntentFilter("kr.ac.koreatech.msp.recordeAlarm");
                registerReceiver(ViewUpdateReceiver, intentFilter1);
                isViewUpdateReceiver = true;
                mStartTime.append(getCurrentTime());
            }
        } else if (v.getId() == R.id.btStop) {
            checkStartbutton = false;
            mTotalStep.setText("steps : 0");
            stopService(new Intent(this, PeriodicMonitorService.class));

            firstvalue = 0;
            //mTotalTime.setText("real steps : " + firstvalue);
            if(isViewUpdateReceiver == true) {
                unregisterReceiver(ViewUpdateReceiver);
            }
        }
    }

    /*
    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_STEP_DETECTOR) {
            firstvalue++;
            mTotalTime.setText("real steps : " + firstvalue);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {
    }
    */

    public void updateScrollView() {
        //브로드캐스트 받으면 계속해서 update 해줌.
        int ismoving = 0;
        String place = null;
        String time = null;
        int isinside = 0;
        int accureMin = 0;
        int prevMoving = 0;
        String prevPlace = null;
        String prevTime = null;
        int previsinside = 0;
        c = db.rawQuery("select * from contacts", null);
        c.moveToFirst();
        String startTime = c.getString(3);

        resultText.setText("======================================\n");
        while (!c.isAfterLast()) {
            ismoving = c.getInt(1);
            place = c.getString(2);
            time = c.getString(3);
            isinside = c.getInt(4);

            Log.d(LOGTAG, "ismoving : " + ismoving + " place : " + place + " time : " + time + " isinside : " + isinside);

            if(ismoving == 0){
                if(prevMoving == 1){
                    Log.d(LOGTAG, "moving -> notmoving");
                    resultText.append(startTime + " - " + time + "\t 움직임 \t" + " 걸음수 : " + accureMin*90 + "\n");

                    startTime = time;
                    accureMin = 0;
                    accureMin++;
                }
                if (prevMoving == 0) {
                    accureMin++;
                    Log.d(LOGTAG, "notmoving~~");
                }
            }

            if(ismoving == 1){
                if(prevMoving == 1){
                    accureMin++;
                    Log.d(LOGTAG, "moving~~");
                }
                if(prevMoving == 0){
                    Log.d(LOGTAG, "notmoving -> moving");
                    //그동안 기록 기록.
                    if(accureMin >= 5) { // 5분 이상 멈춘 상태 지속
                        if(previsinside == 1)
                            resultText.append(startTime + " - " + time + "\t 정지 \t" + " 장소 : " + prevPlace + "\t 실내" + "\n");
                        else if(previsinside == 0)
                            resultText.append(startTime + " - " + time + "\t 정지 \t" + " 장소 : " + prevPlace + "\t 실외" + "\n");
                    }
                    startTime = time;
                    accureMin =0;
                    accureMin++;
                }
            }
            prevMoving = ismoving;
            prevPlace = place;
            prevTime = time;
            previsinside = isinside;
            c.moveToNext();
        }

        if(ismoving == 0){
            if(accureMin >= 5) { // 5분 이상 멈춘 상태 지속
                if(previsinside == 1)
                    resultText.append(startTime + " - " + time + "\t 정지 \t" + " 장소 : " + prevPlace + "\t 실내" + "\n");
                else if(previsinside == 0)
                    resultText.append(startTime + " - " + time + "\t 정지 \t" + " 장소 : " + prevPlace + "\t 실외" + "\n");
            }
        }
        if(ismoving == 1){
            resultText.append(startTime + " - " + time + "\t 움직임 \t\t" + " 걸음수 : " + accureMin*90 + "\n");
        }

    }

    public String getCurrentTime() {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy.MM.dd ", Locale.KOREA);
        Date currentTime = new Date();
        String dTime = formatter.format(currentTime);
        return dTime;
    }

}
