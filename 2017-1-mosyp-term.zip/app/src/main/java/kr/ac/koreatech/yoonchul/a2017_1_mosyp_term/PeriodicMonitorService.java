package kr.ac.koreatech.yoonchul.a2017_1_mosyp_term;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.SystemClock;
import android.support.v7.app.NotificationCompat;
import android.util.Log;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Created by yoonchul on 2017-05-20.
 */
//기본적으로 가속도 센서값 계속 받아오기.
//GPS Monitor 도 여기서. 진행
public class PeriodicMonitorService extends Service implements SensorEventListener{

    private final String LOGTAG2 = "GPSMonitor";
    private LocationManager mLocationManager = null;

    private double lon = 0.0;
    private double lat = 0.0;
    private boolean issendGPS = false;


    WIFIMonitor wifiMonitor;

    private static final String LOGTAG = "PeriodicMonitor";

    AlarmManager am;
    AlarmManager am2;
    PendingIntent pendingIntent;
    PendingIntent pendingIntent1;

    //알람 주기 생성하기 위한 주기 관련 변수들.
    private long period = 30000; // gps 주기
    private static final long periodForMoving = 30000; // 움직였을때 gps 주기
    private static final long periodIncrement = 5000; // 움직이지 않을때 증가되는 gps주기
    private static final long periodMax = 60000; // gps 최대 주기
    private static final long periodForRecord = 60000; // 1분마다 기록 하기 위한 주기기


   private PowerManager.WakeLock wakeLock;
    private CountDownTimer timer;

    private SensorManager mSensorManager;
    private Sensor mLinear;

    //시간 계산 하기 위해
    private long prevT, currT;

    //계산할 스텝
    private int steps = 0;
    final private int NUMBER_OF_SAMPLES = 150; // SENSOR_DELAY_FASTEST는 초당 200개의 샘플 얻어옴 ->  150개 샘플 0.75초 판단
    final private double AVG_RMS_THRESHOLD = 1.5;   //1초간 평균값을 이용하여 걸음이 있었는지를 판단하기 우한 기준 문턱값
    private double[] rmsArray;
    private static final double NUMBER_OF_STEPS_PER_SEC = 1.125;  //1분에 90걸음 걷는다 가정 -> 1초에 1.5걸음 -> 0.75초에 1.125
    private int rmsCount = 0;
    private int NomoveCount = 0;

    //이동과 정지 상태를 체크 하기 위한 변수
    private boolean isStay = false; // 움직이고 있는걸로

    //디비에 저장하기 위한 변수
    int ismoving = 0 ; //0이면 정지, 1이면 움직임
    String place;
    //DB 저장을 위한 변수
    private DBHelper helper;
    private SQLiteDatabase db;

    private final static String LOGTAG3 = "recordAlarm";


    boolean isrequestLocation = false;

    int isinside = 0;





    public String getCurrentTime() {
        SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss", Locale.KOREA);
        Date currentTime = new Date();
        String dTime = formatter.format(currentTime);
        return dTime;
    }

    LocationListener locationListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location location) {
            Log.d(LOGTAG2, "GPS location changed");
            Log.d(LOGTAG2, " Time : " + getCurrentTime() + " Longitude : " + location.getLongitude()
                    + " Latitude : " + location.getLatitude() + " Altitude: " + location.getAltitude()
                    + " Accuracy : " + location.getAccuracy());
            lon = location.getLongitude();
            lat = location.getLatitude();

            issendGPS = true;
            isinside = 0;
            //10초안에 gps 값 받았으니, 등록된 장소와 가까이 있는지 계산
            //그런데, gps accururacy 25보다 낮으면 실내라고 판단.
            if(location.getAccuracy() <25) {
                isinside = 1;
                outdoorTrack(lat, lon);
            }
            onStop();
        }

        @Override
        public void onStatusChanged(String s, int status, Bundle bundle) {
            Log.d(LOGTAG2, "GPS status changed. status code: " + status);
            if (status == 2)
                Log.d(LOGTAG2, "status: Available");
            else if (status == 1)
                Log.d(LOGTAG2, "status: Temporarily unavailable");
            else if (status == 0)
                Log.d(LOGTAG2, "status: Out of service");
            Toast.makeText(getApplicationContext(), "GPS status changed.", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onProviderEnabled(String provider) {
            Log.d(LOGTAG2, "GPS onProviderEnabled: " + provider);
        }

        @Override
        public void onProviderDisabled(String provider) {
            Log.d(LOGTAG2, "GPS onProviderDisabled: " + provider);
            Toast.makeText(getApplicationContext(), "GPS is off, please turn on!", Toast.LENGTH_LONG).show();

        }
    };
    //현재장소가 운동장과 대학본부 앞 잔디 광장 벤치 가까이 있는지 검사
    private void outdoorTrack(double lat, double lon){
        //현재 움직이지 않고 있을때만 트래킹 시작.
            //운동장이다!
            if (measure(lat, lon, 36.762581, 127.284527) <= 80) {
                Log.d(LOGTAG2, "i`m in undongjang");
                ismoving = 0;
                place = "undongjang";
            }
            //대학본부 앞 잔디광장 벤치다!
            if (measure(lat, lon, 36.764215, 127.282173) <= 50) {
                Log.d(LOGTAG2, "bench");
                ismoving = 0;
                place = "bench";
            }
    }

    // 위도와 경도를 이용한 거리 계산
    private float measure(double lat1, double lon1, double lat2, double lon2) {
        double r = 6378.137; // Radius of earth in KM
        double dLat = lat2 * Math.PI / 180 - lat1 * Math.PI / 180;
        double dLon = lon2 * Math.PI / 180 - lon1 * Math.PI / 180;
        double a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                        Math.sin(dLon/2) * Math.sin(dLon/2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        double d = r * c;
        return (float)d * 1000; // meters
    }


    //gps매니저 등록,변수 초기화
    public void onStart() {
        mLocationManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
        try {
            Log.d(LOGTAG2, "mLocationManager obtained");
            mLocationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 3000, 0, locationListener);
            isrequestLocation = true;
        } catch(SecurityException se){
            se.printStackTrace();
            Log.e(LOGTAG2, "PERMISSION_NOT_GRANTED");
        }

        issendGPS = false;

        //10초 카운트 다운.
        //여기서 10초 카운트 해서 gps 10초이상 되면 바로 와이파이 스캔으로 넘어가기.
        //그렇지 않고 10초안에 gps 잡히면 밖에 있는거다!
        timer = new CountDownTimer(10000, 10000) {
            @Override
            public void onTick(long l) {}
            @Override
            public void onFinish() {
                //10초 지났는데 locationChanged 되지 않았으면,
                //리스너 해제 및 onstop()
                if(issendGPS == false){
                    Log.d(LOGTAG2, "time over(10 seconds)");
                    isinside = 1;
                    onStop();
                    //안에 있다는 뜻이니, wifiscan으로 넘어가기.
                    wifiMonitor.onStart();
                }
                else
                    isinside = 0;
            }
        };
        timer.start();
    }

    //gps 매니저 해제
    public void onStop(){
        Log.d(LOGTAG2, "Stop mLocationManager");
        try{
            if(isrequestLocation == true) {
                mLocationManager.removeUpdates(locationListener);
                isrequestLocation = false;
            }
        }catch(SecurityException se){
            se.printStackTrace();
            Log.e(LOGTAG2, "PERMISSION_NOT_GRANTED");
        }
        mLocationManager = null;

        //gps 매니저 해제 되면서 하나의 gps 값 받앗으니, 알람 재설정.
        setNextAlarm();
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////////////////////////////////////////


    //움직임 여부에 따라 기간을 달리해서 알람을 받기 위한 알람 브로드캐스트 리시버
    private BroadcastReceiver AlarmReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if(intent.getAction().equals("kr.ac.koreatech.msp.gpsalarm")){
                Log.d(LOGTAG, "Alarm fired!!!");

                // 동작확인용 바이브레이터
                //vib.vibrate(200);

                PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GPS_Wakelock");
                wakeLock.acquire();

                //웨이크락 잡고, GPS 값 받기 위한 객체 생성 및 onStart 함수 시작
                onStart();

                wakeLock.release();
                wakeLock = null;
            }
        }
    };

    //기록을 위한 알람 1분에 한번씩 alarm 받음.
    private BroadcastReceiver recordReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if(intent.getAction().equals("kr.ac.koreatech.msp.recordeAlarm")){

                //이거 wakelock 잡아야 되는지 궁금
                PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "RECORD_Wakelock");
                wakeLock.acquire();

                if(wifiMonitor.getPlace() != null) {
                    //wifi place 값이 null 이 아니면, 현재 실내에 와이파이 값을 가지고 있다는 뜻
                    //움직이지 않고, 실내에 있다.
                    place = wifiMonitor.getPlace();
                    ismoving = 0;
                    isinside = 1;
                }

                Log.d(LOGTAG3, "new data is saved" + " ismoving : " + ismoving+ " place : " + place + " time " + getCurrentTime() + "isinside : " + isinside);

                //현재 움직임과 장소 저장.
                db.execSQL("insert into contacts values(null, '" +ismoving +"' , '"+place+"' , '" + getCurrentTime()+"' , '" + isinside + "');");

                //record를 위한 새로운 알람 발생.
                Intent intent2 = new Intent("kr.ac.koreatech.msp.recordeAlarm");
                pendingIntent1 = PendingIntent.getBroadcast(getApplicationContext(), 0 , intent2, 0);
                am2.setExact(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime()+  periodForRecord , pendingIntent1); // 60초 알람
                wifiMonitor.setPlace(null);

                wakeLock.release();
                wakeLock = null;
            }
        }
    };

    public void setNextAlarm() {
        if(NomoveCount >= 1000) { //5초이상 움직이지 않았다. -> 알람 주기 증가
            Log.d(LOGTAG, "NOT MOVING!! period plus");
            period = period + periodIncrement;
            if(period >= periodMax) {
                period = periodMax;
            }
        }
        else{ // 움직임이 있다.
            Log.d(LOGTAG, "MOVING!! period minus");
            period = periodForMoving;
        }
        //gpsMonitor 불러올 알람 다시 설정, period
        Intent in = new Intent("kr.ac.koreatech.msp.gpsalarm");
        pendingIntent = PendingIntent.getBroadcast(getApplicationContext(), 0 , in, 0);
        am.setExact(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + period ,pendingIntent);

    }

    @Override
    public IBinder onBind(Intent intent) {return null;}

    @Override
    public void onCreate(){
        Log.d(LOGTAG, "onCreate()");
        prevT = currT = 0;

        helper = new DBHelper(this);
        try {
            db = helper.getWritableDatabase();
        } catch (SQLiteException e) {
            db = helper.getReadableDatabase();
        }

        wifiMonitor = new WIFIMonitor(getApplicationContext());
        //rmsArray init
        rmsArray = new double[NUMBER_OF_SAMPLES];

        mSensorManager = (SensorManager)getSystemService(Context.SENSOR_SERVICE);
        mLinear = mSensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);
        //SensorEventListener 등록
        mSensorManager.registerListener(this, mLinear, SensorManager.SENSOR_DELAY_FASTEST);

        //broadcast를 수신할 receiver 등록
        IntentFilter intentFilter = new IntentFilter("kr.ac.koreatech.msp.gpsalarm");
        registerReceiver(AlarmReceiver, intentFilter);
        am = (AlarmManager)getSystemService(ALARM_SERVICE);
        //현재 데이터를 디비에 저장하기 위한 record receiver 등록
        IntentFilter intentFilter2 = new IntentFilter("kr.ac.koreatech.msp.recordeAlarm");
        registerReceiver(recordReceiver, intentFilter2);
        am2 = (AlarmManager)getSystemService(ALARM_SERVICE);

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId){
        Toast.makeText(this, "Activity Monitor 시작", Toast.LENGTH_SHORT).show();
        Log.d(LOGTAG, "onStartCommand");

        //Alarm이 발생할 시간이 되었을 때, 안드로이드 시스템에 전송할 펜딩인텐트와 방송 지정
        Intent in = new Intent("kr.ac.koreatech.msp.gpsalarm");
        pendingIntent = PendingIntent.getBroadcast(getApplicationContext(), 0 ,in, 0);

        //Alarm 발생할 시간 및 alarm 발생시 이용할 pending intent 설정
        //period에 따라 알람 발생
        am.setExact(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + period, pendingIntent);

        //record를 위한 Alarm 발생
        Intent intent2 = new Intent("kr.ac.koreatech.msp.recordeAlarm");
        pendingIntent1 = PendingIntent.getBroadcast(getApplicationContext(), 0 , intent2, 0);
        am2.setExact(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime()+  periodForRecord , pendingIntent1); // 60초 알람


        //현재 트래킹 상태를 보여주기위한 notification
        Intent intent_noti = new Intent(this, MainActivity.class);
        PendingIntent pIntent = PendingIntent.getActivity(this, 0 ,intent_noti, PendingIntent.FLAG_UPDATE_CURRENT);
        Notification noti = new Notification.Builder(this)
                .setContentTitle("Location tracking")
                .setContentText("Service is running...")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentIntent(pIntent)
                .build();

        startForeground(123,noti);

        return Service.START_STICKY;
    }

    public void onDestroy(){
        unregisterReceiver(AlarmReceiver);
        unregisterReceiver(recordReceiver);
        Toast.makeText(this, "Activity Monitor 중지", Toast.LENGTH_SHORT).show();
        mSensorManager.unregisterListener(this);
        Log.d(LOGTAG, "service stop");
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        //
        if(event.sensor.getType() == Sensor.TYPE_LINEAR_ACCELERATION){

            currT = event.timestamp;
            double dt = (currT - prevT)/1000000;
            //Log.d(LOGTAG, "time diference = " + dt);
            prevT = currT;

            float[] values = event.values.clone();

            //가속도 센서 값이 바뀌었으니, 가속도 센서에 대한 스텝 카운터, 움직임 여부 계산하는 메소드 호출.
            computeSteps(values);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    private void computeSteps(float[] values){

        double avgRms = 0;
        double rms = Math.sqrt(values[0] * values[0] + values[1] * values[1] + values[2] * values[2]);

        if(rmsCount < NUMBER_OF_SAMPLES){
            rmsArray[rmsCount] = rms;
            rmsCount++;
        }else if(rmsCount == NUMBER_OF_SAMPLES){
            //1초간 rms 값이 모였으면 평균 rms 값을 계산
            double sum = 0;
            for(int i=0 ; i<NUMBER_OF_SAMPLES ; i++){
                sum += rmsArray[i];
            }

            avgRms = sum/NUMBER_OF_SAMPLES;
            //Log.d(LOGTAG, " 1sec avg rms : " + avgRms);

            //rmsCount, fmsArray 초기화
            rmsCount = 0;
            for(int i=0 ; i< NUMBER_OF_SAMPLES ; i++){
                rmsArray[i] = 0;
            }
            //이번 업데이트로 계산된 rms를 배열 첫번째 원소로 저장하고 카운트 1 증가
            rmsArray[0] = rms;
            rmsCount++;
        }

        //움직임이 없으므로, NomoveCount 증가
        if(rms < 4){
            if(NomoveCount <= 6000){ // 30초 카운트
                Log.d(LOGTAG, "NomoveCount plus : " + NomoveCount);
                NomoveCount++;
            }
            else if(NomoveCount >= 6000){
                ismoving = 0;
            }
        }
        else{ // 움직임이 생겼다. -> NomoveCount 0으로 초기화
            //Log.d(LOGTAG, " NomoveCount is init : " + NomoveCount);
            NomoveCount = 0;
            ismoving = 1;
            place = null;
        }

        if(avgRms > AVG_RMS_THRESHOLD){
            steps += NUMBER_OF_STEPS_PER_SEC;
            Log.d(LOGTAG, "steps : " + steps);
            Intent intent = new Intent("StepCounter");
            intent.putExtra("steps", (int)steps);

            //boradcast
            sendBroadcast(intent);
        }
    }

    public void setplace(String place){
        this.place = place;
    }
}
